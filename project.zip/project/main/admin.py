from django.contrib import admin
from .models import youtube
# Register your models here.

admin.site.register(youtube)