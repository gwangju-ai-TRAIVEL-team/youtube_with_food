$(function() {
    // 하단 롤링배너
    
    $("#arrow_right").click(function(){
        $(".food").eq(0).insertAfter(".food:last-child");
    });

    $("#arrow_left").click(function(){
        $(".food").eq(-1).insertBefore(".food:first-child");
    });

    // 롤링배너 클릭 시 클릭 효과

    $(".food").click(function() {
        if ($(this).hasClass("clicked") == false) {
            $(this).addClass("clicked");
            $(this).css({"border": "5px solid blue"});
        }
        else {
            $(this).removeClass("clicked");
            $(this).css({"border": "1px solid blue"});
        };
    });

})